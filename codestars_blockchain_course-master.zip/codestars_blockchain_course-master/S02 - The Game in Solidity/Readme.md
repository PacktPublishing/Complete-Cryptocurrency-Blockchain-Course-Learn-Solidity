# Folder Structure

If you have a look at these folders then follow it with the lectures in the course. If you are at the lecture "Basic Game Functionality" then open the folder and follow along from there. The folders contain the files _at the start of the lecture_. The next folder contains the final files.

So, let's say you are in "C03 - Joining the Game" then that's the start of the lecture "Joining the Game". The final code from the lecture "Joining the Game" is in folder "C04 - Define the Board", which is also the starting point for lecture "Define the Board".

